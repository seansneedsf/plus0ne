const createEventFlow = [
    'Welcome! To get started creating your event, simply just text me a few details.',
    'What name do you want to give your event? Don’t worry, you can always change it later.',
    'Cool! when does your event start and end?',
    'Great! Have an address for the event? If not, you can always start with a city or state.',
    'Perfect! Let’s create a link to your event. What email address can we send it to?',
    'You’re all set! We just sent the link to your email address. Check your spam folder just in case.',
];

module.exports.createEventFlow = createEventFlow;